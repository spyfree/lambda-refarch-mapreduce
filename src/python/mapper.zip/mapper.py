'''
Python mapper function

Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
SPDX-License-Identifier: MIT-0
'''

import boto3
import json
import random
import resource
from io import StringIO
import time
import geopandas as gpd
from shapely.geometry import Point
import rtree 
import warnings
import pandas as pd

rtree

warnings.filterwarnings("ignore", category=FutureWarning)

# create an S3 session
s3 = boto3.resource('s3')
s3_client = boto3.client('s3')

# constants
TASK_MAPPER_PREFIX = "task/mapper/";

def write_to_s3(bucket, key, data, metadata):
    s3.Bucket(bucket).put_object(Key=key, Body=data, Metadata=metadata)

def lambda_handler(event, context):
    
    start_time = time.time()

    job_bucket = event['jobBucket']
    src_bucket = event['bucket']
    src_keys = event['keys']
    job_id = event['jobId']
    mapper_id = event['mapperId']
   
    # aggr 
    output = {}
    line_count = 0
    err = ''

    s3_shape_file = "s3://mapreduce-lambda-ny-trip/taxi_zones.shp"
    shape_df = gpd.read_file(s3_shape_file).to_crs({'init': 'epsg:4326'})
    shape_df.drop(['OBJECTID', "Shape_Area", "Shape_Leng", "borough", "zone"],
                  axis=1, inplace=True)


    # INPUT CSV => OUTPUT JSON

    # Download and process all keys
    for key in src_keys:
        key_dict = json.loads(key)
        file_key = key_dict['key']
        Bytes_range = key_dict['range']
        Bytes_range="bytes=0-70000000"
        response = s3_client.get_object(Bucket=src_bucket,Key=file_key, Range=Bytes_range)
        contents = response['Body'].read().decode('utf-8') 
        #print(contents)
        
        key_month = '2016-01'

        data =  contents.split('\n')[1:]
        df = pd.DataFrame(data,columns=['row'])
        print(df.shape)
        df[['VendorID','tpep_pickup_datetime','tpep_dropoff_datetime','passenger_count','trip_distance','pickup_longitude','pickup_latitude','RatecodeID','store_and_fwd_flag','dropoff_longitude','dropoff_latitude','payment_type','fare_amount','extra','mta_tax','tip_amount','tolls_amount','improvement_surcharge','total_amount']] = df.row.str.split(",",expand=True)
        print(df.shape)
        df.drop(['row'],axis=1,inplace=True)
        #localdf = df[['pickup_longitude', 'pickup_latitude']].copy()
        #localdf['pickup_latitude'] = pd.to_numeric(localdf['pickup_latitude'])
        #localdf['pickup_longitude'] = pd.to_numeric(localdf['pickup_longitude'])

        df['pickup_latitude'] = pd.to_numeric(df['pickup_latitude'])
        df['pickup_longitude'] = pd.to_numeric(df['pickup_longitude'])
        #print(localdf.shape)

        local_gdf = gpd.GeoDataFrame(df, crs={'init': 'epsg:4326'},geometry=[Point(xy) for xy in zip(df['pickup_longitude'], df['pickup_latitude'])])
        local_gdf = gpd.sjoin(local_gdf, shape_df, how='left', op='within')

        print(local_gdf.shape)
        out = local_gdf.to_string()
        
        # for line in contents.split('\n')[1:]:
        #     line_count +=1
        #     try:
        #         data = line.split(',')
        #         pickup_date = data[1][:10]

        #         if pickup_date[:7] != key_month:
        #             continue

        #         longitude = data[5]
        #         latitude = data[6]
        #         pt = Point(float(longitude), float(latitude))
        #         re = gpd.sjoin(gpd.GeoDataFrame(crs={'init': 'epsg:4326'},geometry=[pt]),df, how='left', op='within')
        #         #print(re)
        #         zone = re['zone'][0]

        #         if zone not in output:
        #             output[zone] = {'total_trip_num':0}
        #         output[zone]['total_trip_num'] += 1
        #     except Exception as e:
        #         print(e)
        #         #err += '%s' % e

    time_in_secs = (time.time() - start_time)
    #timeTaken = time_in_secs * 1000000000 # in 10^9 
    #s3DownloadTime = 0
    #totalProcessingTime = 0 
    pret = [len(src_keys), line_count, time_in_secs, err]
    mapper_fname = "%s/%s%s" % (job_id, TASK_MAPPER_PREFIX, mapper_id) 
    metadata = {
                    "linecount":  '%s' % line_count,
                    "processingtime": '%s' % time_in_secs,
                    "memoryUsage": '%s' % resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
               }

    print("metadata", metadata)
    #write_to_s3(job_bucket, mapper_fname, json.dumps(output), metadata)
    write_to_s3(job_bucket, mapper_fname, json.dumps(out), metadata)
    return pret

'''
ev = {
   "bucket": "-useast-1", 
   "keys": ["key.sample"],
   "jobId": "pyjob",
   "mapperId": 1,
   "jobBucket": "-useast-1"
   }
lambda_handler(ev, {});
'''
